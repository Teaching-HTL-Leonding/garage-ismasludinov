using System;
using System.ComponentModel.Design;
using Garage;

namespace Garage.App
{
  class Program
  {
    
    public static void Main()
    {
     
      var garage = new Garage();
      var parkingspot = new ParkingSpot();
      int parkingSpotNumber = 0;
      string licensePLate;
      int selection = 0;
      DateTime entry;
      DateTime exit;

      Console.WriteLine("What do want to do? ");
      Console.WriteLine("1) Enter a car entry ");
      Console.WriteLine("2) Enter a car exit ");
      Console.WriteLine("3) Generate report ");
      Console.WriteLine("4 Exit");
      
      while (selection != 4)
      {
        Console.WriteLine("Your selection: ");
         selection = int.Parse(Console.ReadLine()!);
        if (selection == 1)
        {
          Console.Write("Enter parking spot number: ");
          parkingSpotNumber = int.Parse(Console.ReadLine()!);

          Console.Write("Enter license plate: ");
          licensePLate = Console.ReadLine();

          Console.WriteLine("Enter entry DateTime: ");
          entry = Convert.ToDateTime(Console.ReadLine());

          garage.TryOccupy(parkingSpotNumber, licensePLate, entry);

        }
       /* else if (selection == 2)
        {
          Console.WriteLine("Enter parking spot number: 1");
          parkingSpotNumber = int.Parse(Console.ReadLine()!);
          Console.WriteLine("Enter DateTime: ");
          exit = Convert.ToDateTime(Console.ReadLine());

          garage.TryExit(parkingSpotNumber, exit, costs);
        }*/
        else if (selection == 3)
        {
          garage.GenerateReport();
        }
        else if (selection == 4)
        {
          Console.WriteLine("GoodBye!");
        }
        else
        {
          Console.WriteLine("Incorrect Input!");
        }
      }
    }
  }
}
