using System.ComponentModel;

namespace Garage
{
  public class ParkingSpot
  {
    public string? licensePLate { get; set; }

    public DateTime entryDate { get; set; }

  }

  public class Garage
  {
    public ParkingSpot[] parkingSpots { get; } = new ParkingSpot[50];

    public bool IsOccupied(int parkingSpotNumber)
    {
      if (parkingSpots[parkingSpotNumber] != null)
      {
        return true;
      }
      else
      {
        return false;
      }

    }
    public bool TryOccupy(int parkingSpotNumber, string licensePlate, DateTime entryTime)
    {
      if (parkingSpots[parkingSpotNumber] == null )
      {
        parkingSpots[parkingSpotNumber].licensePLate = licensePlate;
        parkingSpots[parkingSpotNumber].entryDate = entryTime;
        return true;
      }
      else
      {
        return false;
      }
      
    }
    public bool TryExit(int parkingSpotNumber, DateTime exitTime, out decimal costs)
    {
      int minutes = 0;
      minutes = exitTime.Minute - parkingSpots[parkingSpotNumber].entryDate.Minute;  
      if (parkingSpots[parkingSpotNumber] != null)
      {
        parkingSpots[parkingSpotNumber] = null;
        if (minutes <= 15)
        {
          costs = 0;
        }
        else
        {
          costs = (minutes / 30) * 3;
        }
        return true;
      }
      else
      {

        costs = 0;
        return false;
      }
    }
    public void GenerateReport()
    {
     
        Console.WriteLine("| Spot | License Plate |");
        Console.WriteLine("| ---- | ------------- |");
        for (int i = 0; i < 50; i++)
        {
          Console.WriteLine($"| {parkingSpots[i]} | {parkingSpots[i].licensePLate}"  );


        }
      
      }
      
    }

  }

